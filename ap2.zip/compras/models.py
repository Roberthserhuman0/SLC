from django.db import models

# Create your models here.
'''
class Produto(models.Model):
    nome = models.CharField(max_length=64)
    preco = models.DecimalField(max_digits=10, decimal_places=2 )

    def __str__(self):
        return f"{self.nome} valor: {self.preco}R$"

class Pedido(models.Model):
    produto = models.ManyToManyField(Produto, blank=True, related_name="produtos")
    quantidade = models.IntegerField()

    def __str__(self):
        return f"{self.produto} Quant: {self.quantidade}"
    
class Lista(models.Model):
    titulo = models.CharField(max_length=64)
    pedidos = models.ManyToManyField(Pedido, blank=True, related_name="listacompras")
    total = ""

    def __str__(self):
        return f"{self.pedidos}{self.total}"
'''
class Cliente(models.Model):
    nomeCliente = models.CharField(max_length=64)
    nomeLista = models.CharField(max_length=64)

class Lista(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name="Consumidor")
    total = models.IntegerField()

    def __str__(self) -> str:
        return f"id do passageiro:{self.id}  de {self.origin} para {self.destination}"

class Produto(models.Model):
    nome = models.CharField(max_length=64)
    preco = models.DecimalField(max_digits=10, decimal_places=2 )
    lista = models.ManyToManyField(Lista, blank=True, related_name="Compras")

    def __str__(self):
        return f"{self.nome} {self.preco}"