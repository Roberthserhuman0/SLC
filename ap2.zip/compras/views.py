from django.shortcuts import render, HttpResponseRedirect
from django.urls import reverse
from .models import Lista, Produto, Cliente
# Create your views here.
def index(request):
    return render(request,"compras/index.html",{
        "lista": Lista.objects.all()
    })

def pedido(request, pedido_id):
    pedido = Lista.objects.get(id=pedido_id)
    compras = pedido.produto.all()
    non_compras = Produto.objects.exclude(lista=pedido).all()
    return render(request, "comṕras/compras.html", {
        "lista":pedido,
        "compras": compras,
        "non_compras": non_compras
    })