from django.contrib import admin
from .models import Produto, Lista, Cliente

class ProdutoAdmin(admin.ModelAdmin):
    list_display = ("id","nome","preco")

# Register your models here.
admin.site.register(Lista)
admin.site.register(Produto, ProdutoAdmin)
admin.site.register(Cliente)